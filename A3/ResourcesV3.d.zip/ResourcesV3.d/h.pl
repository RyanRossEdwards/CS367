%% h/3 the zero heuristic

h(_, _, 0).
