%% h/2 the zero heuristic

h(_, 0).
